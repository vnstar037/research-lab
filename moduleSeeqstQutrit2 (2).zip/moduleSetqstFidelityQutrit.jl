# ══════════════════════════════════════════════════════════════
# SETQST mit F_target → t  (Fidelity-Bound als Wahl des Thresholds)
#
# Eingabe:  gewünschte Mindest-Fidelity F_target (z.B. 0.95)
# Ablauf:   1. Diagonale messen (Block S1, 1 Circuit)
#           2. je Block  B_k = max √(ρ̂_ii ρ̂_jj),  m_k = Σ_{i≠j} ρ̂_ii ρ̂_jj
#           3. Blöcke aufsteigend nach B_k aufsummieren, solange
#                 r · Δ² ≤ (1 − √F_target)²          (Δ² = Σ m_k der übersprungenen Blöcke)
#           4. t_F = B_k des ersten Blocks, der nicht mehr ins Budget passt (Obergrenze)
#              t_Rausch = 1/√shots (Untergrenze); gültig, wenn t_Rausch ≤ t_F,
#              d.h. shots ≥ 1/t_F².  Sonst Warnung + nötige Shot-Zahl; t bleibt t_F.
#           5. Blöcke mit B_k ≥ t messen (+ Fill-up), SGD + Cholesky
# Ausgabe:  ρ_rec  (bzw. mit return_info=true zusätzlich t, F_bound, Circuits, ...)
#
# F_bound = (1 − √(r·Δ²))²   (Binosi et al., Eq. 14)
#   – deckt nur das Weglassen der Blöcke ab (Truncation), nicht Shot-Rauschen
#   – t wird nie über t_F angehoben, F_target bleibt also (für den Truncation-Fehler) garantiert
#   – r = Rang; Standard: Anzahl der Diagonaleinträge > 0 (obere Schranke)
#
# Benötigt im selben Ordner: moduleTSeeqstQutrit2.jl (Gates, Messung, SGD)
# ══════════════════════════════════════════════════════════════

# TSeeqstMixedQutrit nur einbinden, wenn es nicht schon geladen ist
isdefined(Main, :TSeeqstMixedQutrit) || include(joinpath(@__DIR__, "moduleTSeeqstQutrit2.jl"))

module SetqstFidelityQutrit

using LinearAlgebra
using Printf
using QuantumInformation
using ..TSeeqstMixedQutrit
const TS = TSeeqstMixedQutrit

export RecreatingDensityMatrixWithFidelitySetqstQutrit,
       ChooseThresholdFromFidelity,
       FidelityBoundCurveQutrit,
       BlockStatsQutrit

# ══════════════════════════════════════════════════════════════
# Block-Statistik
# ══════════════════════════════════════════════════════════════

# Blockindex von (i,j): Übergangstypen t_1..t_N (t_1 höchstwertig, wie im Modul)
function block_id(i::Int, j::Int, N::Int)
    id = 0
    for l in 1:N
        a  = (i ÷ 3^(N-l)) % 3
        b  = (j ÷ 3^(N-l)) % 3
        id = id * 4 + TS.transition_type_qutrit(a, b)
    end
    return id
end

# B[k+1] = max √(ρ_ii ρ_jj),   m[k+1] = Σ_{i≠j} ρ_ii ρ_jj   (geordnete Paare)
function BlockStatsQutrit(N::Int, rho_diag::Vector{Float64})
    d = 3^N
    B = zeros(4^N)
    m = zeros(4^N)
    for i in 0:d-1, j in 0:d-1
        i == j && continue
        k = block_id(i, j, N)
        p = rho_diag[i+1] * rho_diag[j+1]
        B[k+1]  = max(B[k+1], sqrt(p))
        m[k+1] += p
    end
    return B, m
end

# Binosi Eq. (14)
function fbound_value(r::Int, Δ2::Float64)
    x = r * Δ2
    return x < 1 ? (1 - sqrt(x))^2 : 0.0
end

# Blöcke, die bei Schwelle t gemessen werden (identisch zu BlocksAboveThresholdQutrit)
function kept_blocks(B::Vector{Float64}, t::Float64)
    tol = max(t, 1e-10)
    return [k for k in 0:length(B)-1 if k == 0 || B[k+1] ≥ tol]
end

# ══════════════════════════════════════════════════════════════
# F_target → t
# ══════════════════════════════════════════════════════════════
function ChooseThresholdFromFidelity(N::Int, rho_diag::Vector{Float64}, F_target::Float64;
                                     r::Union{Int,Nothing}     = nothing,
                                     shots::Union{Int,Nothing} = nothing,
                                     t_choice::Symbol          = :F)
    0 < F_target < 1 || error("F_target muss in (0,1) liegen")
    nb     = 4^N
    r_eff  = max(r === nothing ? count(>(0.0), rho_diag) : r, 1)
    budget = (1 - sqrt(F_target))^2 / r_eff              # erlaubtes Δ²

    B, m  = BlockStatsQutrit(N, rho_diag)
    order = sortperm(B[2:end])                           # Blockindizes k = 1..nb-1, aufsteigend nach B_k

    Δ2  = 0.0
    t   = nothing
    pos = 1
    while pos ≤ length(order)
        b0  = B[order[pos]+1]
        grp = Int[]                                      # Blöcke mit gleichem B_k gehören zusammen
        q   = pos
        while q ≤ length(order) && isapprox(B[order[q]+1], b0; rtol = 1e-12, atol = 1e-15)
            push!(grp, order[q]); q += 1
        end
        mg = sum(m[k+1] for k in grp)
        if Δ2 + mg ≤ budget
            Δ2 += mg                                     # Gruppe wird übersprungen
            pos = q
        else
            t = b0                                       # erster Block, der nicht mehr passt
            break
        end
    end
    t === nothing && (t = nextfloat(maximum(B)))         # alles passt ins Budget
    t_F = t                                              # Obergrenze aus F_target

    # Rauschen: t_Rausch = 1/√shots (Untergrenze), nötige Shot-Zahl n ≥ 1/t_F²
    t_noise      = shots === nothing ? 0.0 : 1 / sqrt(shots)
    shots_needed = ceil(Int, 1 / t_F^2)
    noise_ok     = shots === nothing || t_noise ≤ t_F

    # Wahl innerhalb [t_noise, t_F]; nie über t_F
    t_choice in (:F, :noise) || error("t_choice muss :F oder :noise sein")
    if t_choice == :noise && shots !== nothing
        t = min(t_noise, t_F)                            # vorsichtig: nur Blöcke unter dem Rauschen weglassen
    end

    skipped = [k for k in 1:nb-1 if B[k+1] < t]
    Δ2      = sum((m[k+1] for k in skipped); init = 0.0)

    return (t = t, t_F = t_F, t_noise = t_noise, noise_ok = noise_ok,
            shots_needed = shots_needed, r = r_eff, budget = budget, Δ2 = Δ2,
            F_bound = fbound_value(r_eff, Δ2),
            skipped = skipped, B = B, m = m)
end

# Kurve F_bound(t) gegen Circuit-Zahl n_c(t) (vor Fill-up)
function FidelityBoundCurveQutrit(N::Int, rho_diag::Vector{Float64};
                                  r::Union{Int,Nothing} = nothing)
    r_eff = max(r === nothing ? count(>(0.0), rho_diag) : r, 1)
    B, m  = BlockStatsQutrit(N, rho_diag)
    ts    = sort(unique(vcat(B[2:end], nextfloat(maximum(B)))))
    rows  = NamedTuple[]
    for t in ts
        Δ2 = sum((m[k+1] for k in 1:4^N-1 if B[k+1] < t); init = 0.0)
        nc = TS.count_circuits_for_blocks(kept_blocks(B, t), N)
        push!(rows, (t = t, F_bound = fbound_value(r_eff, Δ2), nc = nc))
    end
    return rows
end

# ══════════════════════════════════════════════════════════════
# Hauptfunktion
# ══════════════════════════════════════════════════════════════
function RecreatingDensityMatrixWithFidelitySetqstQutrit(
    rho_true::Matrix{ComplexF64},
    shots::Int,
    F_target::Float64;
    r::Union{Int,Nothing}   = nothing,    # Rang; nothing → Anzahl ρ̂_ii > 0
    t_choice::Symbol        = :F,         # :F → t = t_F (max. Einsparung); :noise → t = min(1/√shots, t_F)
    n_min::Union{Int,Nothing} = nothing,  # Mindestzahl Circuits (Standard: d+1 = (d²−1)/(d−1))
    return_info::Bool       = false,
    lr::Float64             = 0.1,
    decay::Float64          = 0.9999,
    iterations::Int         = 1000,
    patience::Int           = 200,
    verbose::Bool           = true
)
    N = Int(round(log(3, size(rho_true, 1))))
    d = 3^N
    # d²−1 reelle Parameter, je Circuit d−1 unabhängige Werte (Σp = 1)  ⇒  n_circ ≥ (d²−1)/(d−1) = d+1
    n_min_eff = n_min === nothing ? d + 1 : n_min

    verbose && println("═══ SETQST (F_target) N=$N, F_target=$F_target ═══\n")

    # ── Schritt 1: Diagonale messen (Block S1, wird wiederverwendet) ──
    I_d         = [Matrix{ComplexF64}(I, d, d)]
    diag_counts = TS.DataPredictFromRhoSampledQutrit(rho_true, I_d, shots)[1]
    rho_diag    = Float64.(diag_counts) ./ shots

    # ── Schritt 2–4: Blockstatistik, Budget, t ─────────────────
    sel = ChooseThresholdFromFidelity(N, rho_diag, F_target;
                                      r = r, shots = shots, t_choice = t_choice)
    if !sel.noise_ok
        @warn @sprintf("shots=%d zu klein für F_target=%.3f: t_Rausch=%.4f > t_F=%.4f. Nötig: shots ≥ %d (oder F_target senken). t bleibt t_F; die gemessene Fidelity kann unter F_target liegen.",
                       shots, F_target, sel.t_noise, sel.t_F, sel.shots_needed)
    end

    blocks_all       = collect(0:4^N-1)
    blocks_threshold = kept_blocks(sel.B, sel.t)
    blocks_relevant  = copy(blocks_threshold)
    n_circ           = TS.count_circuits_for_blocks(blocks_relevant, N)
    n_threshold      = n_circ
    blocks_added     = Int[]

    # ── Fill-up: mindestens n_min Circuits, größte B_k zuerst ──
    if n_circ < n_min_eff
        missing_b = setdiff(blocks_all, blocks_relevant)
        sort!(missing_b, by = k -> (-sel.B[k+1], k))
        for k in missing_b
            push!(blocks_relevant, k)
            push!(blocks_added, k)
            n_circ = TS.count_circuits_for_blocks(blocks_relevant, N)
            n_circ ≥ n_min_eff && break
        end
    end
    sort!(blocks_relevant)

    # ── Bound für die tatsächlich übersprungenen Blöcke ────────
    Δ2_final   = sum((sel.m[k+1] for k in setdiff(blocks_all, blocks_relevant)); init = 0.0)
    Fb_final   = fbound_value(sel.r, Δ2_final)
    n_circ_all = TS.count_circuits_for_blocks(blocks_all, N)
    reduktion  = (1 - n_circ / n_circ_all) * 100

    if verbose
        println("── Diagonale ──")
        for i in 0:d-1
            rho_diag[i+1] > 1e-6 && @printf("  ρ[%d,%d] = %.4f\n", i, i, rho_diag[i+1])
        end
        println("\n── Threshold-Entscheidung ──")
        @printf("  F_target:             %.4f\n", F_target)
        @printf("  Rang r (Schätzung):   %d\n", sel.r)
        @printf("  Budget Δ²:            %.3e\n", sel.budget)
        @printf("  t_F (Obergrenze):     %.5f\n", sel.t_F)
        @printf("  t_Rausch (1/√shots):  %.5f   → %s\n", sel.t_noise,
                sel.noise_ok ? "ok (shots ≥ 1/t_F² = $(sel.shots_needed))" :
                               "✗ Shots zu klein, nötig ≥ $(sel.shots_needed)")
        @printf("  t (gewählt, %s):     %.5f\n", string(t_choice), sel.t)
        @printf("  Alle Blöcke:          %d\n", length(blocks_all))
        @printf("  Threshold Blöcke:     %d\n", length(blocks_threshold))
        if !isempty(blocks_added)
            @printf("  Aufgefüllt (+%d):     %d Blöcke\n", length(blocks_added), length(blocks_relevant))
        end
        @printf("  Circuits Standard:    %d\n", n_circ_all)
        @printf("  Circuits SETQST:      %d  (vor Fill-up %d, min %d)\n", n_circ, n_threshold, n_min_eff)
        @printf("  Reduktion:            %.1f%%\n", reduktion)
        @printf("  F_bound (gewählt):    %.4f\n", sel.F_bound)
        @printf("  F_bound (nach Fill-up): %.4f\n\n", Fb_final)
    end

    # ── Schritt 5: Circuits bauen, messen (S1 nicht erneut) ────
    Us = Matrix{ComplexF64}[]
    for b in blocks_relevant
        append!(Us, TS.build_unitaries_for_block(b, N))
    end
    data = vcat([diag_counts],
                TS.DataPredictFromRhoSampledQutrit(rho_true, Us[2:end], shots))

    verbose && println("── SGD + Cholesky ──")
    rho_rec = TS.ProcessDataQutrit(data, Us, shots, N;
        lr = lr, decay = decay, iterations = iterations,
        patience = patience, verbose = verbose)
    rho_rec = Matrix{ComplexF64}(rho_rec)

    F = fidelity(rho_rec, rho_true)
    if verbose
        println("\n── Ergebnisse ──")
        @printf("  Fidelität:           %.4f   (F_target %.4f, F_bound %.4f)\n", F, F_target, Fb_final)
        @printf("  Circuits:            %d / %d  (%.1f%% Reduktion)\n", n_circ, n_circ_all, reduktion)
        @printf("  Spur ρ_rec:          %.6f\n", real(tr(rho_rec)))
        @printf("  Kleinster Eigenwert: %.6f\n", minimum(real(eigvals(rho_rec))))
        println("═"^45)
    end

    if return_info
        return rho_rec, (t = sel.t, t_F = sel.t_F, t_noise = sel.t_noise,
                         noise_ok = sel.noise_ok, shots_needed = sel.shots_needed,
                         F_target = F_target, F_bound = Fb_final,
                         F_bound_selected = sel.F_bound, F = F, r = sel.r,
                         nc = n_circ, nc_threshold = n_threshold, nc_all = n_circ_all,
                         blocks = blocks_relevant)
    end
    return rho_rec
end

end # module SetqstFidelityQutrit
