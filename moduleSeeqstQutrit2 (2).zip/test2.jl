# ══════════════════════════════════════════════════════════════
# Tabelle: Standard vs. SEEQST vs. SETQST (F_target = 0.99, 0.95, 0.90)
# für N = 2, 3, 4 mit zufälligen Dichtematrizen (Algorithm 1)
#
# Start: julia table_methods.jl
# Benötigt im selben Ordner:
#   moduleSeeqstQutrit.jl        (Standard: NonEntangling)
#   moduleSeeqstQutrit2.jl       (SEEQST)
#   moduleTSeeqstQutrit2.jl      (SETQST-Bausteine)
#   moduleSetqstFidelityQutrit.jl (SETQST mit F_target)
#
# Ausgabe: Tabelle im Terminal, results_table.csv, results_table.tex
# ══════════════════════════════════════════════════════════════

cd(@__DIR__)
using LinearAlgebra
using Random
using Printf
using Statistics
using DelimitedFiles
using QuantumInformation

include("moduleSeeqstQutrit.jl")
include("moduleSeeqstQutrit2.jl")
include("moduleTSeeqstQutrit2.jl")
include("moduleSetqstFidelityQutrit.jl")

# Alles qualifiziert ansprechen (kein using → keine Namenskonflikte)
const STD = SeeqstHybridQutrit
const SQ  = SeeqstMixedQutrit
const TS  = TSeeqstMixedQutrit
const SF  = SetqstFidelityQutrit

# ── Einstellungen ─────────────────────────────────────────────
const NS          = [2, 3, 4]
const SHOTS       = 5000                # Shots pro Circuit
const F_TARGETS   = [0.99, 0.95, 0.90]
const N_MAT       = 1                   # Anzahl zufälliger Matrizen pro N (Mittelwert, falls > 1)
const SEED        = 1
const RUN_STANDARD = Dict(2 => true, 3 => true, 4 => true)   # N=4: 2400 Circuits, dauert lange
const ITER        = 1000                # SGD-Iterationen (wie im Modul-Standard)

# ── Hilfsfunktionen ───────────────────────────────────────────
F(ρ_rec, ρ) = fidelity(Matrix{ComplexF64}(ρ_rec), ρ)

# Anzahl wirklich gebauter Circuits eines Blocksatzes (SETQST-Modul)
built_circuits(blocks, N) = sum(length(TS.build_unitaries_for_block(b, N)) for b in blocks)

function circuit_numbers(N)
    blocks = collect(0:4^N-1)
    # Standard: eindeutige NonEntangling-Circuits (wie im playground)
    non    = STD.BuildNonEntanglingCircuitsQutrit(blocks, N)
    n_std  = length(unique(String[c for g in non for c in g if c != ""]))
    # SEEQST: gezählt (2·4^N − 1) und gebaut (unique, wie im Modul gedruckt)
    n_sq_count = TS.count_circuits_for_blocks(blocks, N)
    n_sq_built = length(unique(vcat(SQ.BuildMixedCircuitsQutrit(blocks, N)...)))
    return n_std, n_sq_count, n_sq_built
end

# ── Hauptschleife ─────────────────────────────────────────────
rows = Any[]
for N in NS
    n_std, n_sq_count, n_sq_built = circuit_numbers(N)
    @printf("\n══ N=%d (d=%d) ══  Circuits: Standard %d | SEEQST gezählt %d, gebaut %d\n",
            N, 3^N, n_std, n_sq_count, n_sq_built)

    Fstd = Float64[]; Fsq = Float64[]
    Fset = Dict(Ft => Float64[] for Ft in F_TARGETS)
    Nset = Dict(Ft => Int[]     for Ft in F_TARGETS)   # gezählt (inkl. Fill-up)
    Nset_built = Dict(Ft => Int[] for Ft in F_TARGETS) # wirklich gebaut
    Tset = Dict(Ft => Float64[] for Ft in F_TARGETS)

    for m in 1:N_MAT
        Random.seed!(SEED + 100 * N + m)
        rho = Matrix{ComplexF64}(SQ.GenerateRandomDensityMatrixQutrits(N))
        r   = rank(rho, atol = 1e-10)
        @printf("  Matrix %d/%d: Rang=%d, aktive Niveaus=%d\n", m, N_MAT, r,
                count(>(1e-12), real.(diag(rho))))

        if RUN_STANDARD[N]
            t0 = time()
            ρs = STD.RecreatingDensityMatrixWithNonentanglingQutrit(rho, SHOTS;
                    iterations = ITER, verbose = false)
            push!(Fstd, F(ρs, rho)); @printf("    Standard: F=%.4f  (%.0fs)\n", Fstd[end], time() - t0)
        else
            push!(Fstd, NaN)
        end

        t0 = time()
        ρq = SQ.RecreatingDensityMatrixWithMixedSeeqstQutrit(rho, SHOTS;
                iterations = ITER, verbose = false)
        push!(Fsq, F(ρq, rho)); @printf("    SEEQST:   F=%.4f  (%.0fs)\n", Fsq[end], time() - t0)

        for Ft in F_TARGETS
            t0 = time()
            ρt, info = SF.RecreatingDensityMatrixWithFidelitySetqstQutrit(rho, SHOTS, Ft;
                          return_info = true, iterations = ITER, verbose = false)
            push!(Fset[Ft], info.F)
            push!(Nset[Ft], info.nc)
            push!(Nset_built[Ft], built_circuits(info.blocks, N))
            push!(Tset[Ft], info.t)
            @printf("    SETQST F_target=%.2f: F=%.4f  F_bound=%.4f  t=%.4f  nc=%d (gebaut %d)  (%.0fs)\n",
                    Ft, info.F, info.F_bound, info.t, info.nc, Nset_built[Ft][end], time() - t0)
        end
    end

    push!(rows, (N = N, Fstd = mean(Fstd), nstd = n_std,
                 Fsq = mean(Fsq), nsq = n_sq_count, nsq_built = n_sq_built,
                 Fset = Dict(Ft => mean(Fset[Ft]) for Ft in F_TARGETS),
                 nset = Dict(Ft => round(Int, mean(Nset[Ft])) for Ft in F_TARGETS),
                 nset_built = Dict(Ft => round(Int, mean(Nset_built[Ft])) for Ft in F_TARGETS)))
end

# ── Ausgabe: Terminal ─────────────────────────────────────────
println("\n", "═"^96)
@printf("%-3s %8s %6s %8s %6s", "N", "F_Std", "nc", "F_SEEQST", "nc")
for Ft in F_TARGETS; @printf("  %8s %5s", "F_SETQST", "nc"); end
println("\n", " "^34, join(["  (F_target=$(Ft))   " for Ft in F_TARGETS]))
for r in rows
    @printf("%-3d %8.4f %6d %8.4f %6d", r.N, r.Fstd, r.nstd, r.Fsq, r.nsq)
    for Ft in F_TARGETS; @printf("  %8.4f %5d", r.Fset[Ft], r.nset[Ft]); end
    println()
end
println("═"^96)
println("nc SEEQST/SETQST = gezählt (2 pro Block). Gebaut (wirklich gemessen):")
for r in rows
    @printf("  N=%d: SEEQST %d (gezählt %d)", r.N, r.nsq_built, r.nsq)
    for Ft in F_TARGETS; @printf(" | SETQST %.2f: %d (gezählt %d)", Ft, r.nset_built[Ft], r.nset[Ft]); end
    println()
end

# ── Ausgabe: CSV ──────────────────────────────────────────────
header = ["N", "F_std", "nc_std", "F_seeqst", "nc_seeqst", "nc_seeqst_built"]
for Ft in F_TARGETS
    append!(header, ["F_setqst_$(Ft)", "nc_setqst_$(Ft)", "nc_setqst_built_$(Ft)"])
end
data = Any[permutedims(header)]
for r in rows
    line = Any[r.N, r.Fstd, r.nstd, r.Fsq, r.nsq, r.nsq_built]
    for Ft in F_TARGETS; append!(line, [r.Fset[Ft], r.nset[Ft], r.nset_built[Ft]]); end
    push!(data, permutedims(line))
end
writedlm("results_table.csv", vcat(data...), ',')

# ── Ausgabe: LaTeX ────────────────────────────────────────────
open("results_table.tex", "w") do io
    ncol = 5 + 2 * length(F_TARGETS)
    println(io, "\\begin{tabular}{c", "cc"^(2 + length(F_TARGETS)), "}")
    println(io, "\\toprule")
    print(io, "\$N\$ & \$F_{\\mathrm{Std}}\$ & \$n_c^{\\mathrm{Std}}\$ & \$F_{\\mathrm{SEEQST}}\$ & \$n_c^{\\mathrm{SEEQST}}\$")
    for Ft in F_TARGETS
        print(io, " & \$F_{\\mathrm{SETQST}}^{($(Ft))}\$ & \$n_c^{\\mathrm{SETQST}}\$")
    end
    println(io, " \\\\")
    println(io, "\\midrule")
    for r in rows
        print(io, @sprintf("%d & %.4f & %d & %.4f & %d", r.N, r.Fstd, r.nstd, r.Fsq, r.nsq))
        for Ft in F_TARGETS
            print(io, @sprintf(" & %.4f & %d", r.Fset[Ft], r.nset[Ft]))
        end
        println(io, " \\\\")
    end
    println(io, "\\bottomrule")
    println(io, "\\end{tabular}")
end
println("\n→ results_table.csv, results_table.tex")